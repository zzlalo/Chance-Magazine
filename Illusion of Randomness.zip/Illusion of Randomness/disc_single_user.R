#Author:  Wenqi Zeng, Zhaolin Li,Stephen Portnoy, Kelly Findley
#The codes are for reference. 


#load necessary packages
library(ggplot2)
library(ggforce)

#function to create a disc and allows you to click 50 points
disc_click = function() {
  plot.new()
  plot.window(xlim = c(-1, 1), ylim = c(-1, 1), asp = 1)
  
  symbols(0, 0, circles = 1.07, add = TRUE, fg = "black", bg = "white", inches = FALSE, lwd = 2)
  
  valid_points = 1
  x = numeric(0)
  y = numeric(0)
  
  while(valid_points <= 50) {
    cat("Please click on the disc to select points. Total valid points selected so far:", valid_points, "\n")
    points_clicked = locator(1, type = "n") 
    
    if(sqrt(points_clicked$x^2 + points_clicked$y^2) <= 1) {
      x = c(x, points_clicked$x)
      y = c(y, points_clicked$y)
      valid_points = valid_points + 1
    } else {
      cat("Point is outside the circle. Please click within the circle.\n")
    }
  }
  x = round(x, 4)
  y = round(y, 4)
  return(list(x = x, y = y))
}

#x and y coordinates for the 50 points
all_x = list() 
all_y = list()

#number of students who do the task, default = 1 for single user
ntrials = 1

#allowing ntrials of people to click 50 points
for (i in 1:ntrials) {
  cat(sprintf("Round %d: Please click 50 points on the disc.\n", i))
  clicks = disc_click()
  all_x[[i]] = clicks$x
  all_y[[i]] = clicks$y
  if (i == ntrials) {
    cat("You have finished the task.\n")
  }
}

#creating the radius and theta list 
r_list = list()
theta_list = list()
for (i in 1:ntrials){
  x = all_x[[i]]
  y = all_y[[i]]
  r = sqrt(x ^ 2 + y ^ 2)
  theta = atan2(y, x)
  r_list = append(r_list, list(r))
  theta_list = append(theta_list, list(theta))
}

#ks.test for radius 
pvalue_r = numeric(length(r_list))
for (i in 1:length(r_list)){
  kt = ks.test(r_list[i][[1]], function(y) pbeta(y, 2, 1))
  pvalue_r[i] = kt$p.value
}

#ks.test for theta
pvalue_theta = numeric(length(theta_list))
for (i in 1:length(theta_list)){
  kt = ks.test(theta_list[i][[1]], function(y) punif(y, -pi, pi))
  pvalue_theta[i] = kt$p.value
}

#plot the circle with the 50 points
plot_circle = function(num) {
  
  x_coords = all_x[[num]]
  y_coords = all_y[[num]]
  data = data.frame(x = x_coords, y = y_coords)
  
  plot_title = paste(
    "Observation", num,
    "\n",
    "pvalue_r:", round(pvalue_r[num], 4), 
    "\n",
    "pvalue_theta:", round(pvalue_theta[num], 4)
  )
  
  ggplot(data, aes(x, y)) +
    geom_point() +
    coord_fixed() +
    xlim(-1, 1) +
    ylim(-1, 1) +
    geom_circle(aes(x0 = 0, y0 = 0, r = 1), color = "red", linetype = "dashed", size = 1) +
    labs(x = "x", y = "y", title = plot_title)
}

plot_circle(1)
